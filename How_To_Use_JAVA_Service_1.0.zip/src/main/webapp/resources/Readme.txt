Use this folder to add your project resources such as images, custom javascript libraries, and html files.
This is the only folder you are likely to need when working with your project
